"""
SAM CLI version
"""

__version__ = "1.85.0"
